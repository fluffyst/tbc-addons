local LSM = LibStub("LibSharedMedia-3.0")

if LSM == nil then return end
LSM:Register("sound", "Whisper Alert(Loud)", [[Interface\AddOns\ElvUI_ChannelAlerts\Media\Sounds\whisper_loud.mp3]])