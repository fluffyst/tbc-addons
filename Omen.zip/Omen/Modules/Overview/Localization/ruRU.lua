﻿--  Translation by Eritnull (StingerSoft aka Шептун)
local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("Omen_Overview", "ruRU")
if not L then return end

L["Overview Mode"] = "Режим обзора"
L["Show raid icons"] = "Показать икону рейда"
L["Overview Mode\n|cffffffffShows an overview of high-threat raid members|r"] = "Режим обзора\n|cffffffffПоказывает краткий обзор высокой-угрозы участников рейда"
