local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("Omen_Overview", "esES")
if not L then return end
-- Initial translation courtesy of maqjav - Marosth
L["Overview Mode"] = "Modo visión general"
L["Show raid icons"] = "Muestra iconos de banda"
L["Overview Mode\n|cffffffffShows an overview of high-threat raid members|r"] = "Modo visión general\n|cffffffffMuestra una visión general de los miembros que generan mas amenaza|r"
