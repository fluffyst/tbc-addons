* To create a new localization, create a file named after the locale (for 
example, if you want to create a chinese localization, name the file 
zhCN.lua. Then, copy the contents of enUS.lua into your new file, and 
replace each = true with the proper localization. Be sure to change the 
"enUS" registration at the top of your file to your locale, as well. 

* Please note that individual modules may have localization files as well.